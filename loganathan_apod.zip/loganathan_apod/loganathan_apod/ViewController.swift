//
//  ViewController.swift
//  loganathan_apod
//
//  Created by Mani M on 10/08/24.
//

import UIKit
import Network

class ViewController: UIViewController {
    @IBOutlet var titleLbl: UILabel!
    @IBOutlet var apodImgView: UIImageView!
    @IBOutlet var explanationLbl: UILabel!
    @IBOutlet var activityView: UIActivityIndicatorView!
    @IBOutlet var errorDisplayLbl: UILabel!
    @IBOutlet var apodDateLbl: UILabel!
    
    private var viewmodel = ApiVM()
    let monitor = NWPathMonitor()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        errorDisplayLbl.isHidden = true
        errorDisplayLbl.text = ""
        explanationLbl.text = ""
        titleLbl.text = ""
        apodImgView.layer.cornerRadius = 5
        apodImgView.layer.masksToBounds = true
        apodImgView.layer.borderColor = UIColor.lightGray.cgColor
        apodImgView.layer.borderWidth = 2
        let queue = DispatchQueue(label: "NetworkMonitor")
        monitor.start(queue: queue)
        monitor.pathUpdateHandler = { [self] path in
            DispatchQueue.main.async {
                if path.status == .satisfied {
                    self.activityView.startAnimating()
                    self.errorDisplayLbl.isHidden = true
                    self.errorDisplayLbl.text = ""
                    self.viewmodel.delegate = self
                    self.viewmodel.fetchApodDetail()
                } else {
                    self.activityView.stopAnimating()
                    if let detailData = UserDefaults.standard.value(forKey: "apoddata") as? Data {
                        do {
                            let details = try JSONDecoder().decode(APODModel.self, from: detailData)
                            self.viewmodel.getDetail = details
                        } catch let jsonErr {
                            print("Failed to decode:", jsonErr)
                        }
                        let currentDate = self.getCurrentDate()
                        if self.viewmodel.getDetail?.date != currentDate {
                            self.errorDisplayLbl.isHidden = false
                            self.errorDisplayLbl.text = "We are not connected to the internet, showing you the last image we have."
                        }
                        self.titleLbl.text = "\(self.viewmodel.getDetail?.title ?? "No Data")"
                        self.explanationLbl.text = "\(self.viewmodel.getDetail?.explanation ?? "No Data")"
                        self.apodDateLbl.text = "APOD Date: \(self.viewmodel.getDetail?.date ?? "No Data")"
                        if let imageData = UserDefaults.standard.value(forKey: "imagedata") as? Data {
                            if let imageToCache = UIImage(data: imageData) {
                                self.apodImgView.image = imageToCache
                                self.activityView.stopAnimating()
                            }
                        }
                        
                    } else {
                        self.errorDisplayLbl.isHidden = false
                        self.errorDisplayLbl.text = "Please check your internet connection and try again"
                        self.activityView.stopAnimating()
                    }
                }
            }
        }
    }
    
    func setTheDetail() {
        titleLbl.text = "\(viewmodel.getDetail?.title ?? "No Data")"
        explanationLbl.text = "\(viewmodel.getDetail?.explanation ?? "No Data")"
        apodDateLbl.text = "APOD Date: \(viewmodel.getDetail?.date ?? "No Data")"
        if let imageData = UserDefaults.standard.value(forKey: "imagedata") as? Data {
            if let imageToCache = UIImage(data: imageData) {
                self.apodImgView.image = imageToCache
                self.activityView.stopAnimating()
            }
        }
        if let strUrl = "\(viewmodel.getDetail?.hdurl ?? "No Data")".addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed),
           let imgUrl = URL(string: strUrl) {
            URLSession.shared.dataTask(with: imgUrl, completionHandler: { (data, response, error) in
                if error != nil {
                    DispatchQueue.main.async(execute: {
                        self.activityView.stopAnimating()
                    })
                    return
                }
                DispatchQueue.main.async(execute: {
                    if let unwrappedData = data, let imageToCache = UIImage(data: unwrappedData) {
                        self.apodImgView.image = imageToCache
                        self.activityView.stopAnimating()
                        UserDefaults.standard.setValue(data, forKey: "imagedata")
                    }
                })
            }).resume()
        }
    }
    
    func getCurrentDate() -> String {
           let dateFormatter = DateFormatter()
           dateFormatter.dateFormat = "yyyy-MM-dd"
           return dateFormatter.string(from: Date())

       }
}

extension ViewController: APODVMProtocol {
    func didGetAPODDetail() {
        self.setTheDetail()
    }
    
    func didGetError(error: String) {
        DispatchQueue.main.async {
            self.activityView.startAnimating()
        }
    }
    
}
