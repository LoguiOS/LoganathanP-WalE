//
//  ApiVM.swift
//  loganathan_apod
//
//  Created by Mani M on 10/08/24.
//

import Foundation

protocol APODVMProtocol : AnyObject {
    func didGetError(error:String)
    func didGetAPODDetail()
}

final class ApiVM{
    var getDetail: APODModel?
    weak var delegate : APODVMProtocol!
    
    func fetchApodDetail(){
        let urlString = "https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY"
        guard let url = URL(string: urlString) else {
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let err = error {
                self.delegate.didGetError(error: err.localizedDescription)
                return
            }
            guard let data = data else { return }
            do {
                let details = try JSONDecoder().decode(APODModel.self, from: data)
                self.getDetail = details
                DispatchQueue.main.async {
                    self.delegate.didGetAPODDetail()
                    UserDefaults.standard.setValue(data, forKey: "apoddata")
                }
            } catch let jsonErr {
                print("Failed to decode:", jsonErr)
            }
        }.resume()
    }
}
