//
//  APODModel.swift
//  loganathan_apod
//
//  Created by Mani M on 10/08/24.
//

import Foundation

struct APODModel: Codable {
    var date: String?
    var explanation: String?
    var hdurl: String?
    var media_type: String?
    var service_version: String?
    var title: String?
    var url: String?
}
